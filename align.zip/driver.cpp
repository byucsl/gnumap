#include "align.h"
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    Align* align = new Align();

    //align->setGPU(0);
    align->initScoreMatrix(DEFAULT);
    align->setGapPenalty(-2.0f);

    //generate test data
    const int SEQ_LEN = 34;
    const int SEQ_LEN_B = 34;
    const int NUM_SEQ = 50000000;
    const int BLOCK_SIZE = 128;

    char* seqA = (char*)malloc(NUM_SEQ * SEQ_LEN);
    int randNum;
    srand(12345);
    for ( int i = 0; i < NUM_SEQ * SEQ_LEN; ++i ) {
        randNum = rand() % 4;
        if ( randNum == 0 )
            seqA[i] = 'a';
        else if ( randNum == 1 )
            seqA[i] = 'g';
        else if ( randNum == 2 )
            seqA[i] = 'c';
        else
            seqA[i] = 't';
    }

    char matchSeq[SEQ_LEN_B];
    for ( int i = 0; i < SEQ_LEN_B; ++i ) {
        matchSeq[i] = seqA[i * BLOCK_SIZE];
        seqA[i * BLOCK_SIZE + 1] = matchSeq[i];
        seqA[i * BLOCK_SIZE + 2] = matchSeq[i];
    }

    //initialize data, compute, and gets results
    align->loadMatchSequence((char*)&matchSeq, SEQ_LEN_B);
    align->loadSequences(seqA, SEQ_LEN, NUM_SEQ);

    align->computeAlignments();
    float* scores = align->getScores();

    return 0;
}
