#include "align.h"
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <stdlib.h>
#include <math.h>

#define BLOCK_SIZE 128

extern "C" bool setCudaDevice(int device);
extern "C" const char* initScoreMatrixTexture(float score_matrix[128][128]);
extern "C" const char* setMatchSequence(char* matchSeq, int matchLen);
extern "C" const char* initSequences(int seqALen, int blockSize, int numBlocks);
extern "C" const char* setSequences(char* seqA, int start, int bytes);
extern "C" const char* copyScores(float* scores, int start, int bytes);
extern "C" const char* initRow(int blockSize, int numBlocks, int seqALen);
extern "C" const char* initScores(int blockSize, int numBlocks);
extern "C" long getTotalGlobalMemory();
extern "C" int getMaxGridBlocks();
extern "C" void runAlignKernel(int blocks, int blockSize, int seqALen, int seqBLen, float gap);

Align::Align()
{
    scores = NULL;
}

bool setGPU(int num)
{
    return setCudaDevice(num);
}

double Align::When()
{
    struct timeval tp;
    gettimeofday(&tp, NULL);
    return ((double) tp.tv_sec + (double) tp.tv_usec * 1e-6);
}

void Align::loadMatchSequence(char* seq, int len)
{
    seqB = seq;
    seqBLen = len;
    setMatchSequence(seq, len);
}

void Align::loadSequences(char* seqs, int seqLen, int numSeq)
{
    seqA = seqs;
    seqALen = seqLen;
    this->numSeq = numSeq;

    long globalMem = getTotalGlobalMemory() * 0.75f;
    //printf("amount of global memory: %ld\n", globalMem);

    numBlocks = (int)ceil((float)numSeq / (float)BLOCK_SIZE);
    maxBlocks = globalMem / ((sizeof(float) + sizeof(char)) * seqALen + sizeof(float)) / BLOCK_SIZE;

    int deviceMaxGridBlocks = getMaxGridBlocks();
    if ( maxBlocks > deviceMaxGridBlocks )
        maxBlocks = deviceMaxGridBlocks;

    initSequences(seqLen, BLOCK_SIZE, maxBlocks);
}

void Align::setGapPenalty(float penalty)
{
    gap = penalty;
}

float* Align::getScores()
{
    return scores;
}

void Align::initScoreMatrix(ScoringType type)
{
    switch (type) {

    case BLOSUM62:
        break;

    case DEFAULT:
    default:
        score_matrix['A']['A'] = 10.0f;
        score_matrix['A']['G'] = -1.0f;
        score_matrix['A']['C'] = -3.0f;
        score_matrix['A']['T'] = -4.0f;
        score_matrix['G']['A'] = -1.0f;
        score_matrix['G']['G'] = 7.0f;
        score_matrix['G']['C'] = -5.0f;
        score_matrix['G']['T'] = -3.0f;
        score_matrix['C']['A'] = -3.0f;
        score_matrix['C']['G'] = -5.0f;
        score_matrix['C']['C'] = 9.0f;
        score_matrix['C']['T'] = 0.0f;
        score_matrix['T']['A'] = -4.0f;
        score_matrix['T']['G'] = -3.0f;
        score_matrix['T']['C'] = 0.0f;
        score_matrix['T']['T'] = 8.0f;

        score_matrix['a']['a'] = 10.0f;
        score_matrix['a']['g'] = -1.0f;
        score_matrix['a']['c'] = -3.0f;
        score_matrix['a']['t'] = -4.0f;
        score_matrix['g']['a'] = -1.0f;
        score_matrix['g']['g'] = 7.0f;
        score_matrix['g']['c'] = -5.0f;
        score_matrix['g']['t'] = -3.0f;
        score_matrix['c']['a'] = -3.0f;
        score_matrix['c']['g'] = -5.0f;
        score_matrix['c']['c'] = 9.0f;
        score_matrix['c']['t'] = 0.0f;
        score_matrix['t']['a'] = -4.0f;
        score_matrix['t']['g'] = -3.0f;
        score_matrix['t']['c'] = 0.0f;
        score_matrix['t']['t'] = 8.0f;
        break;

    }
    initScoreMatrixTexture(score_matrix);
}

void Align::computeAlignments()
{
    scores = new float[numSeq];

    initRow(BLOCK_SIZE, maxBlocks, seqALen);
    initScores(BLOCK_SIZE, numBlocks);

    int numIterations = (int)ceil((float)numBlocks / (float)maxBlocks);
    //printf("max blocks: %d, %d\n", maxBlocks, numIterations);

    double t0 = When();

    for ( int i = 0; i < numIterations; ++i ) {
        if ( i == numIterations - 1 ) { //last iteration
            int remainingBlocks = numBlocks - (maxBlocks * i);
            int remainingSeqs = numSeq - (maxBlocks * i * BLOCK_SIZE);
            setSequences(seqA, maxBlocks * i * BLOCK_SIZE, remainingSeqs * seqALen);
            runAlignKernel(remainingBlocks, BLOCK_SIZE, seqALen, seqBLen, gap);
            copyScores(scores, maxBlocks * i * BLOCK_SIZE, sizeof(float) * remainingSeqs);
        }
        else {

            setSequences(seqA, maxBlocks * i * BLOCK_SIZE, maxBlocks * BLOCK_SIZE * seqALen);
            runAlignKernel(maxBlocks, BLOCK_SIZE, seqALen, seqBLen, gap);
            copyScores(scores, maxBlocks * i * BLOCK_SIZE, sizeof(float) * maxBlocks * BLOCK_SIZE);
        }
    }

    double t = When() - t0;

    //printf("\n ----------------------------------------------------------------------\n ");
    //printf( "Computed in %lf seconds", t);
    //printf("\n ----------------------------------------------------------------------\n");

}


